/*
 * PR_Serie.h
 *
 *  Created on: 09/07/2013
 *      Author: Pablo
 */

#ifndef PR_SERIE_H_
#define PR_SERIE_H_

#include "LPC845.h"

#define TXBUFFER_SIZE	120    //arbitrario
#define RXBUFFER_SIZE	120    //arbitrario
#define MAX_DATOS	    30     //arbitrario

//primitivas de recepción y transmisión. No están comprometidas con el HW
void UART0_pushTx(uint8_t dato);
uint16_t UART0_popTx(void);


void UART0_pushRx(uint8_t dato);
int16_t UART0_popRx(void);
void EnviarString (const char *str);
int16_t Transmitir (const void * , uint8_t );
//------------------------------------------------------------------------

//Macro definida para arrancar la Tx y no pinchar capas
#define   START_TX()	USART0->INTENSET = (1 << 2)


//--- en inicializacion de UART

void USART0_init(uint32_t bps, uint8_t len, char par,uint8_t stp);
void Hablitar_Clock_Uart0 ();

#endif /* PR_SERIE_H_ */
