/*
 * primitivas.h
 *
 * Documentacion sobre los pines utilizados del LPC en gral:
 * PIO0_08 USART Rx
 * PIO0_09 USART Tx
 * PIO0_07 Analog temp sensor
 * PIO0_01 PINT3 Tilt switch
 * PIO0_00 Water pump
 * PIO0_27 SCL para la comunicacion I2C
 * PIO0_28 SDA para la comunicacion I2C
 */

#ifndef PRIMITIVAS_H_
#define PRIMITIVAS_H_

#include "drv_func.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "fsl_swm.h"
#include "fsl_swm_connections.h"
#include <fsl_SSD1306_I2C.h>

#include <time.h>
void Inicializar();

#define setCLK(st) SetPIN(DISPLAY_CLK,st);
#define setRST(st) SetPIN(DISPLAY_RST,st);


void setDisplay(uint8_t n);

#define TRAMA_LEN 100
#define CANT_TIMERS 7
#define TMR_IP_VALUE 80000 //Asks for IP address automaticaly probably useless...
#define TMR_RECEIVE_VALUE 95 //The uart transfer should be faster than this...
#define TMR_RTC_VALUE 60000 //vuelve a pedir la hora para corregir desvios
#define TMR_REFRESH_OLED 50 //actualiza la pantalla para que los segundos se vean fluidos
#define TMR_RTC 100 //cuenta 1 seg
#define TMR_MIN 3000 //Check for the hourly span of light
#define TMR_TEMPERATURE 6000//Send an update to ESP32 about temp


char * serial_gets(char * s);
void valido_trama(char * s);
void proceso_trama(char * s);
uint32_t get_usr_key(void);
void atiendo_timers(void);
int get_temp(void);
void i2cHouseKeeping(void);
//get PIO0_07
#define get_ADC_0_07() ADC0->SEQ_CTRL[0]|=(1<<26);

#define WATER_TOGGLE() GPIO_PortToggle(GPIO,0,1U << 0) /*!< Toggle on target LED_RED */

void ADC0_SEQA_IRQHandler(void);
#endif /* PRIMITIVAS_H_ */
