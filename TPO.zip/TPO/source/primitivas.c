/*
 * primitivas.c
 */

#include "primitivas.h"
/*Variables globales del main*/
extern int TMR_events[CANT_TIMERS];
extern unsigned int TMRS[CANT_TIMERS];
extern char trama[TRAMA_LEN];
extern unsigned int non_empty_counter;
extern char aux[TRAMA_LEN];
extern int DISP_MODE;
extern int Flag_trama_valida;
extern int RTC_SEG;
extern char IP[17];
extern struct tm light_span[2];
extern uint32_t baudRate;
extern i2c_master_config_t  i2config;
extern uint32_t frecuency;
extern char FLAG_I2C_COLGADO;
extern int temperatura;

void init_ADC(void){
	//1. Definit los pines a utilizar en el ADC
	//Utilizamos el Puerto 0 PIN 7
	CLOCK_EnableClock(kCLOCK_Swm);//Habilito clock para switch matrix
	SWM0->PINENABLE0&=~(1<<14);//En el manual nos dicen que el BIT 14 es el PIO0_7
	//SWM0->PINENABLE0&=~(1<<15);//En el manual nos dicen que el BIT 15 es el PIO0_6
	CLOCK_DisableClock(kCLOCK_Swm);//Deshabilito el clock para la switch matrix
	//2. Energizar el disp
	//En el projecto habilitar el driver ADC
	SYSCON->PDRUNCFG &= ~((uint32_t)(1<<4));
	//3. Habilitar los clocks y seleccionar su frecuencia
	//garantizo un 0 en ADC CLOCK DIVISOR
	SYSCON->ADCCLKDIV&=~(0xFF);
	//Coloco un 1 para dividir el clock por 1 sin esto esta deshabilitado
	SYSCON->ADCCLKDIV|= 0x01;
	//Habilitamos la SWM y configuramos el pin del pote

	//4. Seleccionar los pines que se utilizaran

	//5. Calibrar el ADC
	ADC0->CTRL &= ~(0xFF);
	ADC0->CTRL |= ((SystemCoreClock/(500000))-1)& 0xFF;
	ADC0->CTRL &= ~((uint32_t)(1<<10));//Disable LOWPWR MODE
	ADC0->CTRL &= ~((uint32_t)(1<<8));
	//Inicio la auto calibracion
	ADC0->CTRL |= (uint32_t)(1<<30);
	for(int i=1;i<10000;i++){
		if(!(ADC0->CTRL & ((uint32_t)(1<<30) )) )
			break;
	}
	SYSCON->SYSAHBCLKCTRL0|=(1<<24);//Habilita clock para el ADC
	ADC0->INTEN=0;//deshabilito momentaneamente para config
	ADC0->TRM &=~(1<<5); //Modo alta tension
	ADC0->SEQ_CTRL[0]=0;//Secuencia A el subindice 1 es la seq B
	ADC0->SEQ_CTRL[0]|=0x01;//Agregamos el canal 0 (ADC0)
	ADC0->SEQ_CTRL[0]|=(1<<30);
	ADC0->SEQ_CTRL[0]|=(1<<31);//Habilitamos la Seq A
	ADC0->INTEN |=0x01;//Habilitamos la interrupcion en el periferico
	NVIC->ISER[0]|=(1<<16);
	//6. Configurar las caracteristicas del ADC y las secuencias
}
void init_interruptions(){
	//habilito el clock
	    CLOCK_EnableClock(kCLOCK_GpioInt);
	    //reiniciamos el periferico
	    SYSCON->PRESETCTRL0 &= ~(1<<28);
	    SYSCON->PRESETCTRL0 |= (1<<28);
	    //interrupcion externa 3 al pin 0 12
		SYSCON->PINTSEL[3] &= ~0x3F;
		SYSCON->PINTSEL[3] |= 12;
		//interrupcion externa 4 al pin 0 16
		SYSCON->PINTSEL[4] &= ~0x3F;
		SYSCON->PINTSEL[4] |= 16;
		//TERMINAR DE CONFIGURAR EL PIN0 16
		//Para el pint 3
		PINT->ISEL &= ~(1<<3);
		//Int por flanco ascendente
		PINT->SIENR = (1<<3);
		//limpio por las dudas el registro descendente de la int 3
		PINT->CIENF = (1<<3);
		//Limpio estas int por las dudas del reset
		PINT->RISE = (1<<3);
		//habilito el nvic
		NVIC->ISER[0]=(1<<27);
		NVIC->ISER[0]=(1<<28);
}
void Inicializar(){

	CLOCK_EnableClock(kCLOCK_Iocon);
	CLOCK_EnableClock(kCLOCK_Gpio0);
	CLOCK_EnableClock(kCLOCK_Gpio1);
	CLOCK_EnableClock(kCLOCK_Swm);

	/*Pines del display*/
	SWM_SetMovablePinSelect(SWM0, kSWM_I2C1_SDA, kSWM_PortPin_P0_28);  // SDA to PIO0_28
	SWM_SetMovablePinSelect(SWM0, kSWM_I2C1_SCL, kSWM_PortPin_P0_27);  // SCL to PIO0_27

	SWM_SetPinFunction( FNC_U0_Tx, SWM_PP_U0_Tx);
	SWM_SetPinFunction( FNC_U0_Rx, SWM_PP_U0_Rx);
	Hablitar_Clock_Uart0 ();
	USART0_init(115200, 8,'N',1);
	//Set pins as output
	SetDIR(LED_R, SALIDA);
	SetDIR(LED_G, SALIDA);
	SetDIR(LED_B, SALIDA);
	SetDIR(WATER, SALIDA);
	//Set on-board keys as input
	SetDIR(KEY_USR, ENTRADA);
	SetDIR(KEY_ISP, ENTRADA);
	//Set pins for 7 segment display
	SetDIR(BCD_A, SALIDA);
	SetDIR(BCD_B, SALIDA);
	SetDIR(BCD_C, SALIDA);
	SetDIR(BCD_D, SALIDA);

	SetDIR(DISPLAY_RST,SALIDA);
	SetDIR(DISPLAY_CLK,SALIDA);

	SetPINMODE_IN(IOCON_KEY_USR, PULL_UP);
	SetPINMODE_IN(IOCON_KEY_ISP, PULL_UP);

	SetPINMODE_OUT(IOCON_LED_R,PUSH_PULL);
	SetPINMODE_OUT(IOCON_LED_G,PUSH_PULL);
	SetPINMODE_OUT(IOCON_LED_B,PUSH_PULL);

	SetPINMODE_OUT(IOCON_BCD_A,PUSH_PULL);
	SetPINMODE_OUT(IOCON_BCD_B,PUSH_PULL);
	SetPINMODE_OUT(IOCON_BCD_C,PUSH_PULL);
	SetPINMODE_OUT(IOCON_BCD_D,PUSH_PULL);
	SetPINMODE_OUT(IOCON_DISPLAY_RST,PUSH_PULL);
	SetPINMODE_OUT(IOCON_DISPLAY_CLK,PUSH_PULL);

	SetPIN(LED_R, LED_OFF);
	SetPIN(LED_G, LED_OFF);
	SetPIN(LED_B, LED_OFF);
	SetPIN(WATER, HIGH);

	init_interruptions();
	init_ADC();
	CLOCK_DisableClock(kCLOCK_Swm);

	SysTickInic ( SystemCoreClock/100);
}


volatile int medicion;

void ADC0_SEQA_IRQHandler(void){
	medicion=(ADC0->DAT[0]>>4)&0x0FFF;
	//ADC0->FLAGS|=(1<<28);
	ADC0->FLAGS|=(1<<26);
}

void setDisplay(uint8_t n){
	SetPIN(BCD_A,n&0x0001);
	SetPIN(BCD_B,(n&0x0010)>>1);
	SetPIN(BCD_C,(n&0x0100)>>2);
	SetPIN(BCD_D,(n&0x100)>>3);
}

char * serial_gets(char * s)
{

	int c;
	//no esta el carac de terminacion y recibo algo
	if(strchr(s,'$')==NULL && (c = UART0_popRx()) != '\n' && c >= 0){
		*(s+strlen(s))=c;
	}
	if(strchr(s,'$')!=NULL){
		*(s+strlen(s))='\0';
	}
	return (s);
}

void valido_trama(char * s){
	//Comparo contra los strings que espero encontrar????
	if(*(s+0)!='#'){
		Flag_trama_valida=0;
	}else{
        if (*(s+1)!='$' && strchr(s,'$')!=NULL)//no es vacio ni le falta el terminador
        {
        	Flag_trama_valida=1;
        }
	}
}

void proceso_trama(char * s){
	char respuesta[255];
	memset(respuesta,0,sizeof(respuesta));//init en 0
	if(strstr(s,"Temperatura")!= NULL){
		//ESP32 consulta temperatura
		/*
		if(snprintf(respuesta, sizeof respuesta, "%d", get_temp())>0){
			EnviarString(respuesta);
		}
		*/
		temperatura=atoi(strncpy(respuesta,s+13,2));
	}
    //Baaseline test green led deprecated
    if(strstr(s,"ON")!= NULL){
    		//Enciendo LED
    		//EnviarString("Enciendo LED\n\0");
    		OLED_Clear();
			OLED_Set_Text(5, 42, kOLED_Pixel_Set, "LED ON", 2);
			OLED_Refresh();
    		SetPIN(LED_G, 0);
    	}
    if(strstr(s,"IP")!= NULL){
    	strncpy(IP,s+4,strlen(s)-5);//Me guardo la IP
    }
    //deprecated
    if(strstr(s,"OFF")!= NULL){
        		//Enciendo LED
    			//EnviarString("Apago LED\n\0");
    			OLED_Clear();
				OLED_Set_Text(5, 42, kOLED_Pixel_Set, "LED OFF", 2);
				OLED_Refresh();
        		SetPIN(LED_G, 1);
        	}
    //End of baseline test
    if(strstr(s,"#Water:on$")!= NULL){
    		SetPIN(WATER,LOW);//Relay is active low
    	}
    if(strstr(s,"#Water:off$")!= NULL){
			SetPIN(WATER,HIGH);//Relay is active low
		}
    if(strstr(s,"#Hora:")!= NULL){
      strncpy(respuesta,s+6,strlen(s)-7);
      RTC_SEG=atoi(respuesta);//no usar time_t que el lpc lo implemento distinto
	  // Format time, "yyyy-mm-dd hh:mm:ss zzz"
	  struct tm ts = *localtime(&RTC_SEG); //Local time is GMT
	  char buf[80];
	  memset(buf,0,sizeof(buf));//borro
	  strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &ts);
	  OLED_Clear();
	  OLED_Set_Text(5, 22, kOLED_Pixel_Set, strncpy(respuesta,buf,11), 2);
	  OLED_Set_Text(5, 42, kOLED_Pixel_Set, (buf+11), 2);
	  OLED_Refresh();
	}
    //espacio para configuracion de horarios
    if(strstr(s,"#light-span=")!= NULL){
    	char dos_num_aux[3];
    	light_span[0].tm_hour=atoi(strncpy(dos_num_aux,s+12,2));
    	light_span[0].tm_min=atoi(strncpy(dos_num_aux,s+15,2));
    	light_span[1].tm_hour=atoi(strncpy(dos_num_aux,s+18,2));
    	light_span[1].tm_min=atoi(strncpy(dos_num_aux,s+21,2));
    	/* Muestro por pantalla los numeros en modo de debug
    	OLED_Clear();
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, itoa(light_span[0].tm_hour,dos_num_aux,10), 2);
		OLED_Refresh();

		OLED_Clear();
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, itoa(light_span[0].tm_min,dos_num_aux,10), 2);
		OLED_Refresh();

		OLED_Clear();
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, itoa(light_span[1].tm_hour,dos_num_aux,10), 2);
		OLED_Refresh();

		OLED_Clear();
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, itoa(light_span[1].tm_min,dos_num_aux,10), 2);
		OLED_Refresh();
		*/
    }
    if(strstr(s,"#Pump")!= NULL){
    	char aux[4];
    	EnviarString("#Pump:");
		EnviarString(itoa(!GetPIN(WATER),aux,10));
		EnviarString("$\n\0");
    	//PRINTF("Pump=%d",!GetPIN(WATER));
    }
}

uint32_t get_usr_key(void){
	return(!GetPIN(0, 4));
}

int get_temp(){
	//hago una aproximacion lineal de la tension con la medicion del adc
	//1.386V son 1785 para el adc
	//0.918V son 1190 para el adc
	//la curva entonces sera medicion = 1271.36752*Volts+22.8846
	//levanto la medicion
	get_ADC_0_07();
	//PRINTF("Medicion= %d \n",medicion);
	//aproximo los volts por la medicion
	float Vo=(medicion-22.8846)/1271.36752;
	float R1 = 10000;
	float logR2, R2, T, Tc;
	T=0;
	Tc=0;
	float c1 = 1.009249522e-03, c2 = 2.378405444e-04, c3 = 2.019202697e-07;
	R2 = R1 * (1023.0 / Vo - 1.0);
	logR2 = log(R2);
	T = (1.0 / (c1 + c2*logR2 + c3*logR2*logR2*logR2));//cuentas falopas de internet Steinhart–Hart equation
	Tc = T - 273.15;
	//PRINTF("Tc= %d \n",Temp_c);
	return Tc;
}

void i2cHouseKeeping(){
	//destrabo el master en caso de que cuelgue
	if(FLAG_I2C_COLGADO=='1'){
		I2C_MasterInit(I2C1, &i2config, frecuency);                        //initialization
		/* Initialize the SSD1306 display*/
		OLED_Init();
		FLAG_I2C_COLGADO='0';
	}
	//refresh display
	OLED_Clear();
	if(DISP_MODE==0){
		if(strlen(IP)>12){
					char aux[8];
					//Con escala de letra 2 no entra todo en una linea
					strncpy(aux, IP, 7);
					aux[7]='\0';
					OLED_Set_Text(5, 26, kOLED_Pixel_Set, aux, 2);
					memset(aux,0,sizeof(aux));//borro
					strcpy(aux, (IP+7));
					OLED_Set_Text(5, 42, kOLED_Pixel_Set, aux, 2);
				}else{
					OLED_Set_Text(5, 42, kOLED_Pixel_Set, IP, 2);
				}
	}
	if(DISP_MODE==1){
		struct tm ts = *localtime(&RTC_SEG); //Local time es GMT
		char aux[12];
		char buf[80];
		strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &ts);
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, strncpy(aux,buf,11), 2);
		OLED_Set_Text(5, 42, kOLED_Pixel_Set, (buf+11), 2);
	}
	if(DISP_MODE==2){
		//Display temperature
		//levantar temp
		char aux[4];
		OLED_Set_Text(5, 22, kOLED_Pixel_Set, "Temperature:", 2);
		OLED_Set_Text(5, 42, kOLED_Pixel_Set, itoa(temperatura,aux,10), 2);
		}
	OLED_Refresh();
}

void atiendo_timers(void){
	//timer for temp
	if(TMR_events[6]==1){
		TMR_events[6]=0;
		TMRS[6]=TMR_TEMPERATURE;
		char aux[4];
		EnviarString("#Temp:");
		EnviarString(itoa(temperatura,aux,10));
		EnviarString("$\n\0");
		}
	if(TMR_events[5]==1){
		//Check if in hourly span
		TMR_events[5]=0;
		TMRS[5]=TMR_MIN;
		LED_GREEN_OFF();
		struct tm ts = *localtime(&RTC_SEG);
		int aux_ts = ts.tm_hour*60+ts.tm_min;
		int aux_span0 = light_span[0].tm_hour*60+light_span[0].tm_min;
		int aux_span1 = light_span[1].tm_hour*60+light_span[1].tm_min;
		if((aux_ts>=aux_span0) && (aux_ts<=aux_span1)){//dentro del light span
			LED_RED_OFF();
			LED_GREEN_ON();
		}
	}
	if(TMR_events[4]==1){
		//add 1 second to RTC
		RTC_SEG+=1;
		TMR_events[4]=0;
		TMRS[4]=TMR_RTC;
		}
	if(TMR_events[3]==1){
		i2cHouseKeeping();
		TMR_events[3]=0;
		TMRS[3]=TMR_REFRESH_OLED;
	}
	//Si se vencio el tiempo para pedir la hora la pido al esp32
	if(TMR_events[2]==1){
		//Pido Hora desde internet para mostrar
		EnviarString("#Hora$\n");
		TMR_events[2]=0;
		TMRS[2]=TMR_RTC_VALUE;
	}
	//Si se vencion el recieve timer valido
	if(TMR_events[1]==1){
		valido_trama(trama);//valido lo que levante
		if(Flag_trama_valida==0){//Si es invalido borro
			memset(trama,0,sizeof(trama));//Borro
		}
		TMR_events[1]=0;//termine de validar puedo volver a recibir
		TMRS[1]=TMR_RECEIVE_VALUE;
	}
	//Si se vencio el send timer vuelvo a enviar
	if(TMR_events[0]==1){
		//Pido IP para mostrar
		EnviarString("#IP$\n");
		TMR_events[0]=0;
		TMRS[0]=TMR_IP_VALUE;
	}
}
//Escribimos las interrupciones
void PIN_INT3_IRQHandler(void){
	PINT->RISE = (1<<3);
	//display mode has 3 modes for the time being
	//so to toggle I +1 and %3
	DISP_MODE=(DISP_MODE+1)%3;
	//Forcibly ask for IP OR time
	if(DISP_MODE==0){
		EnviarString("#IP$\0\n");
	}
	if(DISP_MODE==1){
		EnviarString("#Hora$\n\0");
		}
	//Mode to show temp
	if(DISP_MODE==2){
		TMR_events[6]=1;
	}
	/*Apagaria todo por int bajo alguna otra condicion?*/
}
