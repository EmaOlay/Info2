/**
 Inicializacion del puerto serie
 */

#include "pr_uart0.h"
#include "drv_base.h"
#include "fsl_clock.h"
#include "LPC845.h"

void USART0_init(uint32_t bps, uint8_t len, char par,uint8_t stp)
{
USART_Type *base= (USART_Type *)USART0;

	// Configuracion USART (CFG). - ver Tabla 324

	base->CFG = 0;
	base->CFG |= ((len-7)&0x03)<<2;		// Longitud del dato

	switch (par)
	{
	case 'N': // sin paridad
			break;
	case 'O': // paridad impar - Odd
		base->CFG |= 0x03 << 4;	// Parity
		break;
	case 'E': // sin paridad - Even
		base->CFG |= 0x02 << 4;	// Parity
			break;
	}

	if (stp==2)	// 2 bits de stop
		base->CFG |= 1<<6;	// stop len


	// velocidad de transmisión - se omite parámetro OSR
	base->BRG= (SystemCoreClock/bps)/16;

	base->CTL =0;	// reset value =0

	// ---- Habilitamos inetrrupciones
	  base->INTENSET|= 1<<0;	// Rx Ready InterruptEnable

	  // de la tabla 110 - ISER0 0xE000 E1000
	  NVIC->ISER[0] |= 1<<USART0_IRQn;

	  // habilitamos la UART 0
	  base->CFG |= 1;			//Enable

}
#define OFFSET_CLK_UART0	0x90
void Hablitar_Clock_Uart0 ()
{
	// -- seleccionamos la fuente del clock  - FRO
	// SYSCON_BASE - direccion base del SYSCON (System Configuration) - LPC845.h
	// Nota: no es una suma de punteros
	*((uint32_t*)(SYSCON_BASE+OFFSET_CLK_UART0))=0;

	// Habilitamos el clock de la UART
	CLOCK_EnableClock(kCLOCK_Uart0);

	/* Reinicimos (limpia) el periferico. */
	ResetPeriferico(kCLOCK_Uart0);

}
//----------------------------------------------------------------------------
