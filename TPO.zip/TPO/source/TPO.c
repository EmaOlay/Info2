/*
 * Copyright 2016-2022 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    LPC845_systick_basico.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC845.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */

#include "primitivas.h"
#include "mi.h"
/* TODO: insert other definitions and declarations here. */
/*******************************************************************************
 * Variables
 ******************************************************************************/
uint32_t baudRate = 400000;
uint32_t frecuency = 12000000;
/*I2C para el display*/
i2c_master_config_t  i2config;        // config. variable. i2c
char FLAG_I2C_COLGADO='0';
int temperatura;

char trama[TRAMA_LEN];
char IP[17];//Worst case scenary IP
int RTC_SEG=0;//Variable for mantaining the RTC in seconds
struct tm light_span[2];
int Flag_trama_valida=0;
//Vector de eventos son solo flags que me indican que hay algo por hacer
//pos 0: send
//pos 1: receive
int TMR_events[CANT_TIMERS]={0,0,0,0,0,1,0};
//Vector de timers son solo flags que me indican que hay algo por hacer
//pos 0: send
//pos 1: receive
int DISP_MODE=0;
//modo del display
//When 0 display IP address
//When 1 display time
unsigned int TMRS[CANT_TIMERS]={TMR_IP_VALUE,TMR_RECEIVE_VALUE,TMR_RTC_VALUE,TMR_REFRESH_OLED,TMR_RTC,TMR_MIN,TMR_TEMPERATURE};
int main(void) {
    /* Init board hardware. */
	BOARD_InitBootPins();
    BOARD_BootClockFRO30M();/*Set FRO to 30Mhz*/
    BOARD_InitBootPeripherals();
    CLOCK_Select(kI2C1_Clk_From_MainClk);
    I2C_MasterGetDefaultConfig(&i2config);// get the default config of i2c
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    //PRINTF("Hello World\n");

    Inicializar();

    //------DEFAULT CONFIG---------------
    //	  masterConfig.enableMaster  = true;
    //    masterConfig.baudRate_Bps  = 100000U;
    //    masterConfig.enableTimeout = false;
	i2config.baudRate_Bps = baudRate;                                  //adjusting the baudrate to the OLED oscillator
	I2C_MasterInit(I2C1, &i2config, frecuency);                        //initialization
	/* Initialize the SSD1306 display*/
	OLED_Init();
	///* Kind of a welcome message
	OLED_Clear();
	OLED_Set_Text(10, 42, kOLED_Pixel_Set, "Init OK", 2);
	OLED_Refresh();
	for(int i=0; i<2500000;i++){};//un wait para mostrar el mensaje
	//*/
	/*Inicio la trama en 0*/
    memset(trama,0,sizeof(trama));

    while(1) {

    	if(Flag_trama_valida==0){
    		serial_gets(trama);
    	}
    	if(Flag_trama_valida==1){
    		//hay una trama valida proceso accion y borro al terminar
    		proceso_trama(trama);
    		memset(trama,0,sizeof(trama));//Borro despues de actuar
    	}
    	atiendo_timers();
    }
    return 0 ;
}
