
#ifndef TIMER_H_
#define TIMER_H_

#include "LPC845.h"
#include "drv_timer.h"
#include "primitivas.h"

#define DV_FRC_TMR 400


#endif /* TIMER_H_ */
