/*
 * mi.c
 *
 *  Created on: Oct 26, 2022
 *      Author: ema
 */
#include "primitivas.h"
extern int TMR_events[CANT_TIMERS];
extern unsigned int TMRS[CANT_TIMERS];
extern char trama[TRAMA_LEN];


void SysTick_Handler(void)
{
	//Solo resto los contadores y levanto flags
	//En atiendo_timers se procesa y se reinician
	for(int i =0;i<CANT_TIMERS;i++){
		if(TMRS[i]!=0){
			TMRS[i]--;
		}else{
			TMR_events[i]=1;
		}
	}
}
