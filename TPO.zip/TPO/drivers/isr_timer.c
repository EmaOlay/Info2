/*
 * isr_timer.c
 *
 */
#include "isr_timer.h"

//volatile uint8_t flag_1seg = 0;
/*
volatile uint32_t SysTickMod768=0;
volatile uint32_t count_1msMod10s=0;
*/

volatile uint32_t tick100ms=0;

volatile uint8_t Display7segBuffer[6];

/*
 * @brief   ISR de SysTick
 */
/*
void SysTick_Handler(void)
{

	static int counter = 0;
	counter++;
	counter%=DV_FRC_TMR;
	if(counter ==0)
		flag_1seg = 1;


	SysTickMod768++;
	SysTickMod768%=768;

	static int counter = 0;
	counter++;
		counter%=(DV_FRC_TMR/1000);
		if(counter ==0)
			count_1msMod10s++;
		count_1msMod10s%=10000;


	static int counter = 0;
	counter%=(DV_FRC_TMR/10);
	if(!counter){
		tick100ms++;
		tick100ms%=6;

		setDisplay(10);
		if(tick100ms==0){
			setRST(HIGH);
		}
		else
		{
			setRST(LOW);
			setCLK(HIGH);
		}
		setDisplay(Display7segBuffer[tick100ms]);
	}
	else
	{
		setCLK(LOW);
	}
}
*/
