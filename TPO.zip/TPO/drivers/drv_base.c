/*
 * drv_base.c
 *
 *  Created on: Sep 19, 2022
 *      Author: gmand
 */

#include "LPC845.h"

void SWM_SetPinFunction( uint32_t func, uint32_t swm_port_pin)
{

	// SWM0_BASE dirección base de la tabla de asignacion de pines de la SWM - LPC845.h
    uint32_t temp;
    uint32_t pinassign = (uint32_t)func / 4U;	// offset address
    uint32_t shifter   = ((uint32_t)func % 4U) * 8U;	// byte a modificar

    temp = *((uint32_t*)SWM0_BASE + pinassign);
    temp &= ~(0xFFUL << (shifter));
    temp |= ((uint32_t)swm_port_pin << shifter);
    *((uint32_t*)SWM0_BASE + pinassign) = temp;
}


void ResetPeriferico (uint32_t perif)
{
/* bit dentro de PRESETCTRLx - bits 0 a 4 (valores de 0 a 31)

  bit 16:
        0- PRESETCTRL0
        1- PRESETCTRL1

A zero in any assigned bit in this register resets the specified
peripheral. A 1 clears the reset and allows the peripheral to
operate.
*/

uint32_t regIndex = (perif >> 16) & 0x00001;
uint32_t bitMask = 1UL << (perif & 0x001F);

	/* reseteamos el registro en SYSCON
	 * ponemos un 1 en el bit correspondiente y luego lo ponemos en 0
	 */

    if (regIndex==0)
    {
        SYSCON->PRESETCTRL0 &= ~bitMask;
        SYSCON->PRESETCTRL0 |= bitMask;
    }
    else
    {
        SYSCON->PRESETCTRL1 &= ~bitMask;
        SYSCON->PRESETCTRL1 |= bitMask;
    }
}

