/*
 * drv_base.h
 *
 *  Created on: Sep 19, 2022
 *      Author: gmand
 */

#ifndef DRV_BASE_H_
#define DRV_BASE_H_


void SWM_SetPinFunction( uint32_t func, uint32_t swm_port_pin);

void ResetPeriferico (uint32_t perif);

#endif /* DRV_BASE_H_ */
