/*
 * drv_stick.h
 *
	Version - clase 19/sep

 */

#ifndef DRV_STICK_H_
#define DRV_STICK_H_


//---  Salidas digitales - leds
#define LED_VERDE	1,0
#define LED_AZUL	1,1
#define LED_ROJO	1,2

#define IOCON_LED_VERDE IOCON_INDEX_PIO1_0
#define IOCON_LED_AZUL  IOCON_INDEX_PIO1_1
#define IOCON_LED_ROJO  IOCON_INDEX_PIO1_2

#define LED_ON	0
#define LED_OFF	1


//--- Entradas digitales ---

#define	TECLA_USR		0,4
#define	TECLA_ISP		0,12

#define IOCON_TECLA_USR IOCON_INDEX_PIO0_4
#define IOCON_TECLA_ISP IOCON_INDEX_PIO0_12


//--------- Add 7 segmentos

#define BCD_A	0,20
#define BCD_B	0,23
#define BCD_C	0,22
#define BCD_D	0,21

#define IOCON_BCD_A IOCON_INDEX_PIO0_20
#define IOCON_BCD_B IOCON_INDEX_PIO0_23
#define IOCON_BCD_C IOCON_INDEX_PIO0_22
#define IOCON_BCD_D IOCON_INDEX_PIO0_21


#define BCD_RST	0,18
#define BCD_CK	0,19

#define IOCON_BCD_RST IOCON_INDEX_PIO0_18
#define IOCON_BCD_CK  IOCON_INDEX_PIO0_19


//========= definicion de pines para UART 0  =========

//=== P 0,26 Uart 0 - Tx
//------ Funcion en Switch Matrix
#define FNC_U0_Tx		0
//------ Definicon de Puerto/Pin en SWM
//PIO0_0 (= 0) to PIO0_31 (= 31 o 0x1F) and from PIO1_0 (= 32 o 0x20) to PIO1_21(= 0x35).
#define SWM_PP_U0_Tx	26

//=== P 0,25 Uart 0 - Rx
//------ Funcion en Switch Matrix
#define FNC_U0_Rx		1
//------ Definicon de Puerto/Pin en SWM
//PIO0_0 (= 0) to PIO0_31 (= 31 o 0x1F) and from PIO1_0 (= 32 o 0x20) to PIO1_21(= 0x35).
#define SWM_PP_U0_Rx	25

#endif /* DRV_STICK_H_ */
