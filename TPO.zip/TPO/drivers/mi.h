/*
 * mi.h
 *
 *  Created on: Oct 25, 2022
 *      Author: ema
 */

#ifndef MI_H_
#define MI_H_

void SysTick_Handler(void);

#endif /* MI_H_ */
