

#ifndef DRV_FUNC_H_
#define DRV_FUNC_H_

#include "drv_gpio.h"
#include "drv_timer.h"
#include "isr_timer.h"
#include "LPC845.h"
#include "fsl_clock.h"
#include "pr_uart0.h"
#include "drv_base.h"

#define LED_G 1,0
#define LED_B 1,1
#define LED_R 1,2
#define WATER 0,0

#define LED_ON 0
#define LED_OFF 1

#define HIGH 1
#define LOW 0

#define KEY_USR 0,4
#define KEY_ISP 0,12

#define IOCON_LED_R IOCON_INDEX_PIO1_2
#define IOCON_LED_G IOCON_INDEX_PIO1_0
#define IOCON_LED_B IOCON_INDEX_PIO1_1

#define IOCON_KEY_USR IOCON_INDEX_PIO0_4
#define IOCON_KEY_ISP IOCON_INDEX_PIO0_12

#define BCD_A 0,20
#define BCD_D 0,21
#define BCD_C 0,22
#define BCD_B 0,23

#define DISPLAY_RST 0,18
#define DISPLAY_CLK 0,19

#define IOCON_BCD_A IOCON_INDEX_PIO0_20
#define IOCON_BCD_D IOCON_INDEX_PIO0_21
#define IOCON_BCD_C IOCON_INDEX_PIO0_22
#define IOCON_BCD_B IOCON_INDEX_PIO0_23

#define IOCON_DISPLAY_RST IOCON_INDEX_PIO0_18
#define IOCON_DISPLAY_CLK IOCON_INDEX_PIO0_19

//========= definicion de pines para UART 0  =========

//=== P 0,26 Uart 0 - Tx
//------ Funcion en Switch Matrix
#define FNC_U0_Tx		0
//------ Definicon de Puerto/Pin en SWM
//PIO0_0 (= 0) to PIO0_31 (= 31 o 0x1F) and from PIO1_0 (= 32 o 0x20) to PIO1_21(= 0x35).
#define SWM_PP_U0_Tx	9

//=== P 0,25 Uart 0 - Rx
//------ Funcion en Switch Matrix
#define FNC_U0_Rx		1
//------ Definicon de Puerto/Pin en SWM
//PIO0_0 (= 0) to PIO0_31 (= 31 o 0x1F) and from PIO1_0 (= 32 o 0x20) to PIO1_21(= 0x35).
#define SWM_PP_U0_Rx	8

#endif /* DRV_FUNC_H_ */
