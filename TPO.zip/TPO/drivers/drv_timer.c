/*
 * timer.c
 *
 */
#include "LPC845.h"
#include "drv_timer.h"


uint32_t SysTickInic ( uint32_t ticks )
{
	if ((ticks - 1UL) > 0xFFFFFF)
    {
      return (1UL);                                                   /* Reload value impossible */
    }
	SYST_RVR = (uint32_t)(ticks - 1UL);
	SYST_CVR = 0;

	CLKSOURCE = 1;
	ENABLE = 1;
	TICKINT = 1;

	return (0UL);
}

