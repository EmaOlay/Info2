/**
 	\file FW_serie.c
 	\brief Drivers de comunicacion serie
*/


#include "LPC845.h"
#include "pr_uart0.h"
uint8_t txStart = 0;  //flag para activar/desactivar transmisión serie


//USART0_IRQHandler   USART0_USART_IRQHANDLER
/**
 	\file FW_serie.c
 	\brief isr de transmisión/recepción serie.
 	\details Analiza si la interrupción fue de Rx o de Tx y opera en consecuencia. No contempla errores
 	\param [in] void
	\return void
*/
void USART0_IRQHandler (void)
{
	int16_t auxTemporal;
	uint32_t stat = USART0->STAT;   //consulto el estado de la UART
	
    // CASO RECEPCION
	if(stat & (1 << 0))  //Receiver Ready Flag. Si vale 1, indica que un dato es disponible para ser leído del buffer del
			             //receptor. Se borra solo luego de leer uno de los registros RXDAT o RXDATSTAT.
	{
		auxTemporal = (int32_t) USART0->RXDAT;    //recibo dato
		UART0_pushRx((uint8_t) auxTemporal);            //manejo bufferRx correctamente
	}

	//CASO TRANSMISION
	if(stat & (1 << 2))  //Transmitter Ready flag.  Si vale 1, indica que se puede escribir en TXDAT.
		// El dato previo podria aún estar en proceso de transmisión. Se borra solo cuando se escribe el registro TXDAT, y se pone en 1
		// cuando el dato es movido desde TXDAT al serializador.
	{
		auxTemporal = UART0_popTx();    //Si hubo una int de Tx, leo del bufferTx y almaceno en variable de trabajo (auxTemporal)
		if(auxTemporal >= 0)      //¿sigue habiendo datos para tx? (popTx() devuelve -1 cuando ya no hay datos para tx)
			USART0->TXDAT = (uint8_t)auxTemporal;  //escribo TXDAT (transmito)
		else
		{   //no hay mas datos.... Desactivo Int Tx
			USART0->INTENCLR = (1 << 2); //disable int TX
			txStart = 0;  //cuando vale 0 indica que no hay tx activa
		}
	}
}


