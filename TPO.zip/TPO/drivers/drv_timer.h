
#ifndef DRV_TIMER_H_
#define DRV_TIMER_H_
#include "LPC845.h"
#include "isr_timer.h"

uint32_t SysTickInic ( uint32_t ticks );
		//!< 0xE000E010UL: Registro de control del SysTick:
	#define 	SYSTICK		( (systick_t *) 0xE000E010UL )

	//!< Tipo de dato especÃ­fico para manejar el SYSTICK
	typedef struct
	{
		union{
			volatile uint32_t SYST_CSR;
			struct{
				volatile uint32_t ENABLE:1;
				volatile uint32_t TICKINT:1;
				volatile uint32_t CLKSOURCE:1;
				volatile uint32_t RESERVED0:13; //bit 3 a 15
				volatile uint32_t COUNTFLAG:1;
				volatile uint32_t RESERVED1:15; //bit 17 a 31
			}bits;
		};
		volatile uint32_t SYST_RVR;
		volatile uint32_t SYST_CVR;
		volatile uint32_t  SYST_CALIB;
	}systick_t;

	#define		SYST_CSR		SYSTICK->SYST_CSR
		#define	ENABLE			SYSTICK->bits.ENABLE
		#define	TICKINT			SYSTICK->bits.TICKINT
		#define	CLKSOURCE		SYSTICK->bits.CLKSOURCE
		#define	COUNTFLAG		SYSTICK->bits.COUNTFLAG
	#define		SYST_RVR		SYSTICK->SYST_RVR
	#define		SYST_CVR		SYSTICK->SYST_CVR
	#define		SYST_CALIB		SYSTICK->SYST_CALIB


//-----------------------------------

#endif /* TIMER_H_ */
